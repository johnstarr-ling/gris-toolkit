// COMMENT: Places progress bar at the bottom of the screen instead of the top.
//          Deleting this code block is not recommended.
(()=>{
    let bar;
    (function barAsLast(){
        bar = bar || document.querySelector("#bod table:first-child");
        if (bar) {
            if (document.body.scrollHeight > window.innerHeight) {
                bar.style.position = 'unset';
                bar.style.bottom = 'unset';
                bar.style.left = 'unset';
                bar.style.transform = 'unset';
                let pc = document.querySelector("p.PennController-PennController");
                if (pc) pc.append(bar);
                else (document.querySelector("#bod table:last-child")||document.body).append(bar);
            }
            else {
                bar.style.position = 'absolute';
                bar.style.bottom = '0px';
                bar.style.left = '50vw';
                bar.style.transform = 'translateX(-50%)';
                document.body.prepend(bar);
            }
        }
        window.requestAnimationFrame(barAsLast);
    })();
})();

// COMMENT: Shorten command names (keep this line here))
PennController.ResetPrefix(null); 


// COMMENT: Uncomment this line only when you are 100% done designing your experiment
// DebugOff()   

// COMMENT: Automatically change group when the participant joins
PennController.SetCounter("increase");


// COMMENT: Experiment sequence
Sequence('increase', rshuffle('demo'), 'end')

// COMMENT: Experiment template
// ADD: Your file name.
Template('items.csv', row => newTrial( "demo" ,
    defaultCanvas.css({'flex-direction':'row','justify-content':'space-evenly'})
        // defaultCanvas.css({'flex-direction':'row'})
    ,
    // ADD: Your label here.
    newText('Top Label').print(100, 70)
    ,
    // ADD: Your label here.
    newText('Bottom Label').print(100, 390)
    ,
    // ADD: Your canvas items here.
	newCanvas('(5, 0, 0)', '34.5em', '2.5em').color('gray').print(250, 50),	
	newCanvas('(5, 1, 0)', '34.5em', '2.5em').color('gray').print(800, 50),	
	newCanvas('(5, 0, 1)', '34.5em', '2.5em').color('gray').print(250, 90),	
	newCanvas('(5, 1, 1)', '34.5em', '2.5em').color('gray').print(800, 90),	
	newCanvas('(4, 0, 0)', '34.5em', '2.5em').color('lightgray').print(250, 130),	
	newCanvas('(4, 1, 0)', '34.5em', '2.5em').color('lightgray').print(800, 130),	
	newCanvas('(4, 0, 1)', '34.5em', '2.5em').color('lightgray').print(250, 170),	
	newCanvas('(4, 1, 1)', '34.5em', '2.5em').color('lightgray').print(800, 170),	
	newCanvas('(3, 0, 0)', '34.5em', '2.5em').color('silver').print(250, 210),	
	newCanvas('(3, 1, 0)', '34.5em', '2.5em').color('silver').print(800, 210),	
	newCanvas('(3, 0, 1)', '34.5em', '2.5em').color('silver').print(250, 250),	
	newCanvas('(3, 1, 1)', '34.5em', '2.5em').color('silver').print(800, 250),	
	newCanvas('(2, 0, 0)', '34.5em', '2.5em').color('whitesmoke').print(250, 290),	
	newCanvas('(2, 1, 0)', '34.5em', '2.5em').color('whitesmoke').print(800, 290),	
	newCanvas('(2, 0, 1)', '34.5em', '2.5em').color('whitesmoke').print(250, 330),	
	newCanvas('(2, 1, 1)', '34.5em', '2.5em').color('whitesmoke').print(800, 330),	
	newCanvas('(1, 0, 0)', '34.5em', '2.5em').color('ghostwhite').print(250, 370),	
	newCanvas('(1, 1, 0)', '34.5em', '2.5em').color('ghostwhite').print(800, 370),	
	newCanvas('(1, 0, 1)', '34.5em', '2.5em').color('ghostwhite').print(250, 410),	
	newCanvas('(1, 1, 1)', '34.5em', '2.5em').color('ghostwhite').print(800, 410),	
	
	// ADD: Your reservoir items here.
    newCanvas("reservoir", "80vw", "1em")
        .color("lightgray")
        .print("center at 50vw", "bottom at 73vh")
        ,
    newCanvas("reservoir2", "80vw", "1em")
        .color("lightgray")
        .print("center at 50vw", "bottom at 76vh")
        ,
        
    // ADD: Your objects here. To facilitate integration with the tookit,
    //      we strongly encourage you to prefix the object columns in your 
    //      data with the `object` label. 
    //      Note that objects can be printed elsewhere, though Text objects
    //      function better when printed in reservoirs.
    //      Image objects do not require reservoirs.
    newText(row.object1).print(getCanvas("reservoir")),
    newText(row.object2).print(getCanvas("reservoir")),
    newText(row.object3).print(getCanvas("reservoir2")),
    newText(row.object4).print(getCanvas("reservoir2")),


    // COMMENT: The drag-drop component of the trial:
    newDragDrop("pt-1", "bungee")       // COMMENT: Bungee means that an object will spring back to its
                                        //          original location if it is not placed in a canvas.
        .addDrag(
                // ADD: Your objects here.
                getText(row.object1),
                getText(row.object2),
                getText(row.object3),
                getText(row.object4)
                )
        .addDrop(
                // ADD: Your canvas items here.
                getCanvas('(5, 0, 0)'), getCanvas('(5, 0, 1)'), getCanvas('(5, 1, 0)'), getCanvas('(5, 1, 1)'),
                getCanvas('(4, 0, 0)'), getCanvas('(4, 0, 1)'), getCanvas('(4, 1, 0)'), getCanvas('(4, 1, 1)'),
                getCanvas('(3, 0, 0)'), getCanvas('(3, 0, 1)'), getCanvas('(3, 1, 0)'), getCanvas('(3, 1, 1)'),
                getCanvas('(2, 0, 0)'), getCanvas('(2, 0, 1)'), getCanvas('(2, 1, 0)'), getCanvas('(2, 1, 1)'),
                getCanvas('(1, 0, 0)'), getCanvas('(1, 0, 1)'), getCanvas('(1, 1, 0)'), getCanvas('(1, 1, 1)'),
                
                // ADD: Your reservoirs here.
                getCanvas("reservoir"),
                getCanvas("reservoir2")
                )
        .swap(
                // ADD: Your canvas items here. You can copy-paste 
                //      from above.
                getCanvas('(5, 0, 0)'), getCanvas('(5, 0, 1)'), getCanvas('(5, 1, 0)'), getCanvas('(5, 1, 1)'),
                getCanvas('(4, 0, 0)'), getCanvas('(4, 0, 1)'), getCanvas('(4, 1, 0)'), getCanvas('(4, 1, 1)'),
                getCanvas('(3, 0, 0)'), getCanvas('(3, 0, 1)'), getCanvas('(3, 1, 0)'), getCanvas('(3, 1, 1)'),
                getCanvas('(2, 0, 0)'), getCanvas('(2, 0, 1)'), getCanvas('(2, 1, 0)'), getCanvas('(2, 1, 1)'),
                getCanvas('(1, 0, 0)'), getCanvas('(1, 0, 1)'), getCanvas('(1, 1, 0)'), getCanvas('(1, 1, 1)'),
                
                // ADD: Your reservoir items here. You can 
                //      copy-paste from above.
                getCanvas("reservoir"),
                getCanvas("reservoir2")
                )
        .offset('unset', getCanvas("reservoir")
                )
        .offset('unset', getCanvas("reservoir2")
                )
        
        // COMMENT: Ensure that all objects have been dropped before
        //          the participant can continue.
        .wait( 
            self.test.dropped(
                getText(row.object1),
                getText(row.object2),
                getText(row.object3),
                getText(row.object4)
                )                  
            )
            .log('all') // COMMENT: Logs all incremental drag-drop events, 
                        //          as well as the final location for all objects.
        ,
        // ADD: Your files here.
        newText('check', 'If have placed the objects where you want them, please hit the button below to continue.')
            .print("center at 50vw", "bottom at 83vh")
            .center(),
        newButton('continue-button', 'Continue')
            .print("center at 50vw", "bottom at 88vh")
            .wait()
            .center()
    ).log("item", row.item)     // COMMENT: Logs item for each trial.
)

    
    

// COMMENT: Uncomment the line below to send your results 
//          to the server. 
// SendResults('send')  



// COMMENT: Final screen.
newTrial("end",
    newText("thanks", "Thank you for participating in this experiment!")
        .center()
        .print()
    ,
    newText('thanks-2', " <p> <br> You may now exit out of this tab. <br>")
        .center()
        .print()
        .wait()
    ,
    // Trick: stay on this trial forever (until tab is closed)
    newButton().wait()
)
.setOption("countsForProgressBar",false)
